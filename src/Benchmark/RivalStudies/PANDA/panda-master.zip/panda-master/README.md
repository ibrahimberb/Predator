# PANDA
To predict change in protein binding affinity upon mutations using sequences

# Dependencies
1-Python 3.6, 
2-Bio Python 1.77,
3-sklearn 0.20

# Usage
Please see and run example.py (For its webserver please visit https://pandaaffinity.pythonanywhere.com/welcome/default/index#)

# To be cited as
Wajid Arshad Abbasi, Syed Ali Abbas, Saiqa Andleeb,PANDA: Predicting the Change in Proteins Binding Affinity Upon Mutations 
by Finding a Signal in Primary Structures, jbcb, 2021,doi: https://doi.org/10.1142/S0219720021500153.
